# PRODIGY_DS_01
* Task 1: Create a Bar Chart or Histogram to Visualize Population Distribution.
* Objective: The objective of creating a bar chart or histogram is to visually represent and analyze the distribution of a specific variable, be it categorical or continuous, within a population, enabling insights into the data's characteristics and patterns.
